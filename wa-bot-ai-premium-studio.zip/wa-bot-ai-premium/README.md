# WA Bot AI Premium Studio

Starter project untuk dashboard sederhana + OpenAI Responses API + WhatsApp Cloud API webhook.

## Penting sebelum mulai
- OpenAI API ditagih terpisah dari langganan ChatGPT; periksa harga dan batas penggunaan di dashboard OpenAI.
- Render Free dapat spin down setelah 15 menit tanpa trafik, jadi tidak menjamin bot aktif tanpa jeda.
- Gunakan WhatsApp Cloud API resmi. Jangan gunakan untuk spam; kirim pesan sesuai kebijakan WhatsApp dan aturan opt-in.
- Jangan masukkan API key/token ke HTML atau repository. Isi hanya di Environment Variables Render.
- Konfigurasi Meta dan billing/API access perlu dilakukan sendiri oleh pemilik akun.

## Jalankan lokal (opsional)
Butuh Node.js 20+:
1. `npm install`
2. Isi environment variables dari `.env.example` di shell/host.
3. `npm start`
4. Buka `http://localhost:3000` dan login dengan DASHBOARD_USER / DASHBOARD_PASSWORD.

## Deploy ke Render dari HP
1. Buat repository baru di GitHub dan unggah isi folder proyek ini.
2. Buka Render, pilih **New + > Web Service**, hubungkan GitHub, lalu pilih repository.
3. Runtime: Node. Build Command: `npm install`. Start Command: `npm start`. Pilih Free jika tersedia.
4. Di **Environment**, tambahkan variabel yang diperlukan. Wajib untuk dashboard/AI: `DASHBOARD_PASSWORD`, `OPENAI_API_KEY`. Tambahkan `DASHBOARD_USER`, `OPENAI_MODEL`, dan `BOT_INSTRUCTIONS` sesuai kebutuhan.
5. Tambahkan variabel WhatsApp setelah menyelesaikan setup Meta: `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_API_VERSION`, dan `META_APP_SECRET`.
6. Setelah deploy, buka URL Render. Login akan diminta oleh browser (HTTP Basic Auth).
7. Tes endpoint kesehatan dengan membuka `/health`. Dashboard ada di `/`.

## Setup OpenAI
1. Buat API key melalui platform OpenAI.
2. Tambahkan sebagai `OPENAI_API_KEY` di Render Environment.
3. Pastikan akun API memiliki akses model dan pengaturan billing/limit yang sesuai. Model dapat diubah melalui `OPENAI_MODEL`.

Dokumentasi: https://developers.openai.com/api/docs/quickstart

## Setup WhatsApp Cloud API
1. Buat aplikasi di Meta for Developers dan tambahkan produk WhatsApp.
2. Ambil access token dan Phone Number ID dari konfigurasi WhatsApp.
3. Tentukan `WHATSAPP_VERIFY_TOKEN` sendiri sebagai string rahasia panjang; isi nilai yang sama di Render dan konfigurasi webhook Meta.
4. Di pengaturan webhook Meta, set callback URL ke `https://NAMA-SERVICE.onrender.com/webhook/whatsapp`, isi verify token yang sama, dan subscribe ke field `messages`.
5. Tambahkan `META_APP_SECRET` di Render untuk memeriksa signature webhook. Setelah mengubah Environment, redeploy/restart service.
6. Ikuti proses pengujian dan verifikasi nomor sesuai instruksi Meta. Pengiriman pesan mengikuti jendela layanan dan template rules WhatsApp.

Dokumentasi resmi:
- WhatsApp Cloud API: https://developers.facebook.com/docs/whatsapp/cloud-api/
- Render deploy: https://render.com/docs/web-services
- Render free limits: https://render.com/docs/free

## Environment variables
- `OPENAI_API_KEY` — rahasia API OpenAI (wajib untuk AI).
- `OPENAI_MODEL` — model API yang tersedia di akun.
- `WHATSAPP_ACCESS_TOKEN` — token Cloud API.
- `WHATSAPP_PHONE_NUMBER_ID` — Phone Number ID.
- `WHATSAPP_VERIFY_TOKEN` — token buatan sendiri untuk verifikasi webhook.
- `WHATSAPP_API_VERSION` — versi Graph API yang didukung Meta saat deploy; perbarui jika diperlukan.
- `META_APP_SECRET` — App Secret dari aplikasi Meta, digunakan untuk signature check.
- `DASHBOARD_USER` dan `DASHBOARD_PASSWORD` — lindungi dashboard.
- `BOT_NAME`, `BOT_INSTRUCTIONS` — nama dan perilaku bot.

## Limitasi starter
- Dashboard sederhana ini belum menyimpan riwayat chat.
- Webhook hanya membalas pesan teks masuk.
- Gratisan Render bisa tidur setelah idle; pesan WhatsApp yang masuk saat server tidur mungkin mengalami keterlambatan atau gagal diproses bergantung pada pengiriman ulang webhook.
- Untuk produksi perlu penyimpanan persisten, rate limiting yang lebih kuat, deduplikasi webhook, logging aman, dan penanganan pesan yang lebih lengkap.
